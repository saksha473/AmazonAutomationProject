package base;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import java.util.List;

import static org.testng.Assert.*;

public class AmazonTest extends BaseTest {

    @Test
    public void testNonExistingProductSearch(){
        // Search for non-existing product
        driver.findElement(By.id("twotabsearchtextbox")).sendKeys("ld345tsxslfer");
        driver.findElement(By.id("nav-search-submit-button")).click();

        assertTrue(driver.getPageSource().contains("No results found"),
                "Expected 'No results found' message.");
    }

    @Test
    public void testExistingProductSearch(){
        // Search for existing product
        driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Laptop");
        driver.findElement(By.id("nav-search-submit-button")).click();

        List<WebElement> products = driver.findElements(By.cssSelector(".s-main-slot .s-result-item"));
        assertTrue(products.size() > 0, "Expected products in search results.");
    }

    @Test
    public void testAddToCart(){
        // Search first
        driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Laptop");
        driver.findElement(By.id("nav-search-submit-button")).click();

        List<WebElement> products = driver.findElements(By.cssSelector(".s-main-slot .s-result-item"));
        products.get(3).click();

        driver.findElement(By.id("add-to-cart-button")).click();

        assertTrue(driver.getPageSource().contains("Added to Cart"),
                "Expected 'Added to Cart' message.");
    }

    @Test
    public void testChangeQty(){
        // Search first
        driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Laptop");
        driver.findElement(By.id("nav-search-submit-button")).click();

        List<WebElement> products = driver.findElements(By.cssSelector(".s-main-slot .s-result-item"));
        products.get(3).click();

        driver.findElement(By.id("add-to-cart-button")).click();

        // Change qty to 2
        driver.findElement(By.name("quantity")).click();
        driver.findElement(By.cssSelector("option[value='2']")).click();

        assertTrue(driver.getPageSource().contains("Qty: 2"),
                "Expected Quantity to be 2.");
    }

    @Test
    public void testRemoveFromCart(){
        // Search first
        driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Laptop");
        driver.findElement(By.id("nav-search-submit-button")).click();

        List<WebElement> products = driver.findElements(By.cssSelector(".s-main-slot .s-result-item"));
        products.get(3).click();

        driver.findElement(By.id("add-to-cart-button")).click();

        // Remove from Cart
        driver.findElement(By.cssSelector(".sc-action-delete")).click();

        assertTrue(driver.findElement(By.cssSelector(".sc-your-amazon-cart-is-empty")).isDisplayed(),
                "Expected Cart to be empty.");
    }
}
